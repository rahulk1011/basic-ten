<?php

namespace Drupal\rkservice\Plugin\rest\resource;
use Drupal\rest\Plugin\ResourceBase;
use Psr\Log\LoggerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
* Provides a resource to get view modes by entity and bundle.
* @RestResource(
*   id = "usa_states_rest",
*   label = @Translation("USA States API"),
*   uri_paths = {
*     "canonical" = "/api/usa-states",
*   }
* )
*/

class StateListRest extends ResourceBase {
	/**
    * A current user instance which is logged in the session.
    * @var \Drupal\Core\Session\AccountProxyInterface
	*/
	protected $loggedUser;

	/**
    * Constructs a Drupal\rest\Plugin\ResourceBase object.
    *
    * @param array $config
    *   A configuration array which contains the information about the plugin instance.
    * @param string $module_id
    *   The module_id for the plugin instance.
    * @param mixed $module_definition
    *   The plugin implementation definition.
    * @param array $serializer_formats
    *   The available serialization formats.
    * @param \Psr\Log\LoggerInterface $logger
    *   A logger instance.
    * @param \Drupal\Core\Session\AccountProxyInterface $current_user
    *   A currently logged user instance.
	*/
	public function __construct(array $config, $module_id, $module_definition, array $serializer_formats, LoggerInterface $logger, AccountProxyInterface $current_user) {
		parent::__construct($config, $module_id, $module_definition, $serializer_formats, $logger);
		$this->loggedUser = $current_user;
	}

	/**
	* {@inheritdoc}
	*/
	public static function create(ContainerInterface $container, array $config, $module_id, $module_definition) {
		return new static(
            $config,
            $module_id,
            $module_definition,
            $container->getParameter('serializer.formats'),
            $container->get('logger.factory')->get('usa_states_api'),
            $container->get('current_user')
		);
	}

	/*
	* Get list of USA States API
	*/
	public function get() {
		global $base_url;
		try {
            $config = \Drupal::config('imaservices.settings');
            $webservice_wsdl_url = $config->get('imaservices.service1_api_url');
            $webservice_location_url = $config->get('imaservices.service1_api_url_location');
            $webservice_action_url = $config->get('imaservices.service1_api_url_action');
            $webservice_Register_action_url = $config->get('imaservices.service1_RegisterOnLineapi_url_action');
            $username = $config->get('imaservices.service1_api_username');
            $password = $config->get('imaservices.service1_api_password');

			$all_states = array();
			$state_list =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('usa_state_list');
			foreach ($state_list as $states) {
				$state_data['state_code'] = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($states->tid)->get('field_state_code')->getValue()[0]['value'];
				$state_data['state_name'] = $states->name;
				array_push($all_states, $state_data);
			}

			$final_api_reponse = array(
                "status" => "Success",
                "message" => "USA State List",
                "result" => $all_states
			);
			return new JsonResponse($final_api_reponse);
		}
		catch(Exception $exception) {
			$this->exception_error_msg($exception->getMessage());
		}
	}
}	