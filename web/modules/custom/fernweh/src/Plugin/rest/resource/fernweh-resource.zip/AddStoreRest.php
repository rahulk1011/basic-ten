<?php

namespace Drupal\rkservice\Plugin\rest\resource;
use Drupal\rest\Plugin\ResourceBase;
use Psr\Log\LoggerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;

/**
* Provides a resource to get view modes by entity and bundle.
* @RestResource(
*   id = "add_store_rest",
*   label = @Translation("Add Store API"),
*   uri_paths = {
*     "create" = "/api/add-store",
*   }
* )
*/

class AddStoreRest extends ResourceBase {
	/**
    * A current user instance which is logged in the session.
    * @var \Drupal\Core\Session\AccountProxyInterface
	*/
	protected $loggedUser;

	/**
    * Constructs a Drupal\rest\Plugin\ResourceBase object.
    *
    * @param array $config
    *   A configuration array which contains the information about the plugin instance.
    * @param string $module_id
    *   The module_id for the plugin instance.
    * @param mixed $module_definition
    *   The plugin implementation definition.
    * @param array $serializer_formats
    *   The available serialization formats.
    * @param \Psr\Log\LoggerInterface $logger
    *   A logger instance.
    * @param \Drupal\Core\Session\AccountProxyInterface $current_user
    *   A currently logged user instance.
	*/
	public function __construct(array $config, $module_id, $module_definition, array $serializer_formats, LoggerInterface $logger, AccountProxyInterface $current_user) {
		parent::__construct($config, $module_id, $module_definition, $serializer_formats, $logger);
		$this->loggedUser = $current_user;
	}

	/**
    * {@inheritdoc}
	*/
	public static function create(ContainerInterface $container, array $config, $module_id, $module_definition) {
		return new static(
            $config,
            $module_id,
            $module_definition,
            $container->getParameter('serializer.formats'),
            $container->get('logger.factory')->get('add_store_api'),
            $container->get('current_user')
		);
	}

	/*
    * Add Store API
	*/
	public function post(Request $data) {
		try {
			$user = User::load(\Drupal::currentUser()->id());
			$user_id = $user->get('uid')->value;
			$content = $data->getContent();
			$params = json_decode($content, TRUE);

			$message_string = "";
			$message_string .= empty($params['store_name']) ? "Store Name. " : "";
			$message_string .= empty($params['phone_number']) ? "Phone Number. " : "";
			$message_string .= empty($params['store_address']) ? "Address. " : "";
			$message_string .= empty($params['city']) ? "City. " : "";
			$message_string .= empty($params['state']) ? "State. " : "";
			$message_string .= empty($params['zipcode']) ? "Zipcode. " : "";

            if ($message_string) {
                $final_api_reponse = array(
                    "status" => "Error",
                    "message" => "Mandatory Fields Missing",
                    "result" => "Required Fields: ".$message_string
                );
            }
            else {
                // Save New Store //
                $store_name = $params['store_name'];
                $new_store_values = array();
                $new_store_values['type'] = 'store';
                $new_store_values['status'] = 1;
                $new_store_values['uid'] = $user_id;
                $new_store_values['title'] = $store_name;
                $new_store_values['field_phone'] = $params['phone_number'];
                $new_store_values['field_store_address'] = $params['store_address'];
                $new_store_values['field_address_2'] = $params['store_address_2'];
                $new_store_values['field_city'] = $params['city'];
                $new_store_values['field_state'] = $params['state'];
                $new_store_values['field_zip_code'] = $params['zipcode'];

                \Drupal::entityTypeManager()->getStorage('node')->create($new_store_values)->save();

                $final_api_reponse = array(
                    "status" => "Success",
                    "message" => "New Store Added",
                    "result" => "New store location added successfully: ".$store_name
                );
            }
			return new JsonResponse($final_api_reponse);
		}
		catch(Exception $exception) {
			$this->exception_error_msg($exception->getMessage());
		}
	}
}