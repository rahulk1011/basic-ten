<?php

namespace Drupal\rkservice\Plugin\rest\resource;
use Drupal\rest\Plugin\ResourceBase;
use Psr\Log\LoggerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Drupal\user\Entity\User;

/**
* Provides a resource to get view modes by entity and bundle.
* @RestResource(
*   id = "add_retailer_rest",
*   label = @Translation("Add Retailer API"),
*   uri_paths = {
*     "create" = "/api/add-retailer",
*   }
* )
*/

class AddRetailerRest extends ResourceBase {
	/**
    * A current user instance which is logged in the session.
    * @var \Drupal\Core\Session\AccountProxyInterface
	*/
	protected $loggedUser;

	/**
    * Constructs a Drupal\rest\Plugin\ResourceBase object.
    *
    * @param array $config
    *   A configuration array which contains the information about the plugin instance.
    * @param string $module_id
    *   The module_id for the plugin instance.
    * @param mixed $module_definition
    *   The plugin implementation definition.
    * @param array $serializer_formats
    *   The available serialization formats.
    * @param \Psr\Log\LoggerInterface $logger
    *   A logger instance.
    * @param \Drupal\Core\Session\AccountProxyInterface $current_user
    *   A currently logged user instance.
	*/
	public function __construct(array $config, $module_id, $module_definition, array $serializer_formats, LoggerInterface $logger, AccountProxyInterface $current_user) {
		parent::__construct($config, $module_id, $module_definition, $serializer_formats, $logger);
		$this->loggedUser = $current_user;
	}

	/**
    * {@inheritdoc}
	*/
	public static function create(ContainerInterface $container, array $config, $module_id, $module_definition) {
		return new static(
            $config,
            $module_id,
            $module_definition,
            $container->getParameter('serializer.formats'),
            $container->get('logger.factory')->get('add_retailer_api'),
            $container->get('current_user')
		);
	}

	/*
    * Add Retailer API
	*/
	public function post(Request $data) {
		global $base_url;
		try {
			$logged_user = User::load(\Drupal::currentUser()->id());
			$user_id = $logged_user->get('uid')->value;
			$role = $logged_user->get('roles')->getValue();
			$enroller_mail = $logged_user->get('mail')->value;
			$enroller_name = $logged_user->get('field_first_name')->value.' '.$logged_user->get('field_last_name')->value;
			$existing_enroller_data = $logged_user->field_enroller_data->getString();
			$existing_enroller_data_array = explode(', ', $existing_enroller_data);

            $content = $data->getContent();
			$params = json_decode($content, TRUE);

			if($role[0]['target_id'] == 'enroller') {
				$message_string = "";
				// User Details
				$message_string .= empty($params['email_id']) ? "Email ID. " : "";
				$message_string .= empty($params['first_name']) ? "First Name. " : "";
				$message_string .= empty($params['last_name']) ? "Last Name. " : "";
				$message_string .= empty($params['phone_number']) ? "Phone Number. " : "";
				$message_string .= empty($params['enroller']) ? "Enroller Type. " : "";
				// Mailing Information
				$message_string .= empty($params['mailing_name']) ? "Mailing Name. " : "";
				$message_string .= empty($params['mailing_address']) ? "Mailing Address. " : "";
				$message_string .= empty($params['mailing_city']) ? "Mailing City. " : "";
				$message_string .= empty($params['mailing_state']) ? "Mailing State. " : "";
				$message_string .= empty($params['mailing_zip']) ? "Mailing Zip Code. " : "";
				// Store Details
				$message_string .= empty($params['store_name']) ? "Store Name. " : "";
				$message_string .= empty($params['store_phone_number']) ? "Store Phone Number. " : "";
				$message_string .= empty($params['store_address']) ? "Store Address. " : "";
				$message_string .= empty($params['store_city']) ? "Store City. " : "";
				$message_string .= empty($params['store_state']) ? "Store State. " : "";
				$message_string .= empty($params['store_zip']) ? "Store Zip Code. " : "";
				if($message_string) {
					$final_api_reponse = array(
					"status" => "Error",
					"message" => "Mandatory Fields Missing",
					"result" => "Required fields: ".$message_string
					);
				}
				else {
					$user_name = strtolower($params['first_name'].'_'.$params['last_name']).'_'.date('dmy');
					$user_full_name = ucfirst($params['first_name']).' '.ucfirst($params['last_name']);
					$user_email = $params['email_id'];
					$user_type = $params['user_type'];
					$characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
					$retailer_password = '';
					for ($i = 0; $i < 8; $i++) {
						$index = rand(0, strlen($characters) - 1);
						$retailer_password .= $characters[$index];
					}
					$email_check = \Drupal::entityQuery('user')->condition('mail', $user_email)->execute();
					$username_check = \Drupal::entityQuery('user')->condition('name', $user_name)->execute();
					if (!empty($email_check) || !empty($username_check)) {
						$final_api_reponse = array(
						"status" => "Error",
						"message" => "Registration Failed",
						"result" => "User details already exists. Please try with different Name or Email-ID."
						);
					}
					else {
						// Creating a New User
						// The Enroller/Third Party is creating account for Retailers/Store Owners from their account
						$new_user = User::create([
                            'name' => $user_name,
                            'pass' => $retailer_password,
                            'mail' => $user_email,
                            'roles' => array('merchant', 'authenticated'),
                            'field_first_name' => ucfirst($params['first_name']),
                            'field_last_name' => ucfirst($params['last_name']),
                            'field_phone_number' => $params['phone_number'],
                            'field_enroller' => $params['enroller'],
                            'field_enroller_data' => $user_id,
                            'field_mailing_name' => $params['mailing_name'],
                            'field_mailing_address' => $params['mailing_address'],
                            'field_mailing_address_2' => $params['mailing_address_2'],
                            'field_mailing_city' => $params['mailing_city'],
                            'field_mailing_state' => $params['mailing_state'],
                            'field_mailing_zip' => $params['mailing_zip'],
                            'field_subscribe_to_ima_program_e' => $params['ima_program'],
                            'status' => 1,
						])->save();
						// Fetching Retailer-ID to save & map with Enroller
						$retailer = user_load_by_name($user_name);
						$retailer_id = $retailer->id();
						$updated_enroller_data = array_merge($existing_enroller_data_array, array($retailer_id));
						$logged_user->set('field_enroller_data', $updated_enroller_data);
						$logged_user->save();
						
						// Store Information
						$new_store_values = array();
						$new_store_values['type'] = 'store';
						$new_store_values['status'] = 1;
						$new_store_values['uid'] = $retailer_id;
						$new_store_values['title'] = $params['store_name'];
						$new_store_values['field_phone'] = $params['store_phone_number'];
						$new_store_values['field_store_address'] = $params['store_address'];
						$new_store_values['field_address_2'] = $params['store_address_2'];
						$new_store_values['field_city'] = $params['store_city'];
						$new_store_values['field_state'] = $params['store_state'];
						$new_store_values['field_zip_code'] = $params['store_zip'];
						// Mailing information to be sent to MSA
						$new_store_values['field_enroller'] = $params['enroller'];
						$new_store_values['field_first_name'] = $params['first_name'];
						$new_store_values['field_last_name'] = $params['last_name'];
						$new_store_values['mail'] = $params['email_id'];
						$new_store_values['field_store_name'] = $params['store_name'];
						$new_store_values['field_mailing_name'] = $params['mailing_name'];
						$new_store_values['field_mailing_address'] = $params['mailing_address'];
						$new_store_values['field_mailing_address_2'] = $params['mailing_address_2'];
						$new_store_values['field_mailing_city'] = $params['mailing_city'];
						$new_store_values['field_mailing_state'] = $params['mailing_state'];
						$new_store_values['field_mailing_zip'] = $params['mailing_zip'];
						
						\Drupal::entityTypeManager()->getStorage('node')->create($new_store_values)->save();
						// Send Acknowledgement Mail to the Enroller
						\Drupal\imaservices\Plugin\rest\resource\AddRetailerRest::NotifyEnrollerMail($enroller_mail, $enroller_name, $user_full_name);
						// Send Acknowledgement Mail to the Retailer
						\Drupal\imaservices\Plugin\rest\resource\AddRetailerRest::NotifyRetailerMail($user_email, $enroller_name, $user_full_name, $retailer_password);
						$final_api_reponse = array(
                            "status" => "Success",
                            "message" => "Registration Successful",
                            "result" => "Thank You. Retailer account for ".$user_full_name." has been created."
						);
					}
				}
			}
			else {
				$final_api_reponse = array(
                    "status" => "Error",
                    "message" => "Access Denied"
				);
			}
			return new JsonResponse($final_api_reponse);
		}
		catch(Exception $exception) {
			$this->exception_error_msg($exception->getMessage());
		}
	}

	function NotifyEnrollerMail($enroller_mail, $enroller_name, $user_full_name) {
		$mailManager = \Drupal::service('plugin.manager.mail');
		$module = 'imaservices';
		$key = 'enroller_welcome'; // Replace with Your key
		$to = $enroller_mail;
		$site_name = \Drupal::config('system.site')->get('name');

		$params['message'] = '<p>Hello '.$enroller_name.',<br><br>You have successfully added '.$user_full_name.' as a new retailer to Independent Merchandising Allowance (IMA).<br><br>Admin,<br>'.$site_name.'</p>';
		$params['title'] = 'Retailer Registration - '.$user_full_name;

		$langcode = 'en';
		$send = true;
		$reply = \Drupal::config('system.site')->get('mail');

		$result = $mailManager->mail($module, $key, $to, $langcode, $params, $reply, $send);
		\Drupal::logger('add_retailer_api')->notice('<pre><code>'.print_r($result, TRUE).'</code></pre>');
		if ($result['result'] != true) {
			$message = 'There was a problem sending your email notification to '.$enroller_mail;
			\Drupal::logger('add_retailer_api')->error($message);
			return;
		}
		else {
			$message = 'An email notification has been sent to '.$enroller_mail;
			\Drupal::logger('add_retailer_api')->notice($message);
		}
	}

	function NotifyRetailerMail($user_email, $enroller_name, $user_full_name, $retailer_password) {
		$mailManager = \Drupal::service('plugin.manager.mail');
		$module = 'imaservices';
		$key = 'retailer_welcome'; // Replace with Your key
		$to = $user_email;
		$site_name = \Drupal::config('system.site')->get('name');

		$params['message'] = '<p>Hello '.$user_full_name.',<br><br>Thank you for registering at '.$site_name.'. Your Retailer account for Independent Merchandising Allowance (IMA) has been created by '.$enroller_name.'.<br><br>You can now log in with the following credentials:<br>Email : <strong>'.$user_email.'</strong><br>One Time Password : <strong>'.$retailer_password.'</strong><br><br>Please set your desired password at the earliest.<br><br>Admin,<br>'.$site_name.'</p>';
		$params['title'] = 'Welcome to IMA - '.$user_full_name;

		$langcode = 'en';
		$send = true;
		$reply = \Drupal::config('system.site')->get('mail');

		$result = $mailManager->mail($module, $key, $to, $langcode, $params, $reply, $send);
		\Drupal::logger('add_retailer_api')->notice('<pre><code>'.print_r($result, TRUE).'</code></pre>');
		if ($result['result'] != true) {
			$message = 'There was a problem sending your email notification to '.$enroller_mail;
			\Drupal::logger('add_retailer_api')->error($message);
			return;
		}
		else {
			$message = 'An email notification has been sent to '.$enroller_mail;
			\Drupal::logger('add_retailer_api')->notice($message);
		}
	}
}